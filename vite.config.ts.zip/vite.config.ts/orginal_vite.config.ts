import path from "path";
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { cloudflare } from "@cloudflare/vite-plugin";
import { mochaPlugins } from "@getmocha/vite-plugins";

export default defineConfig({
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  plugins: [
// Only use Cloudflare plugins in development/Cloudflare environments
...(process.env.NODE_ENV === "development" || process.env.CF_PAGES ? mochaPlugins(process.env as any) : []),
react(),
// Only include Cloudflare plugin when not building for GitHub Pages
...(process.env.GITHUB_ACTIONS ? [] : [cloudflare()]),
  ],
  // Set base path for GitHub Pages deployment
  base: process.env.GITHUB_ACTIONS ? "/launchdesk-website/" : "/",
  server: {
allowedHosts: true,
  },
  build: {
chunkSizeWarningLimit: 5000,
// Ensure proper build output for static hosting
rollupOptions: {
  output: {
    manualChunks: undefined,
  },
},
  },
  resolve: {
alias: {
  "@": path.resolve(__dirname, "./src"),
},
  },
});